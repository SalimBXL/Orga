--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.25
-- Dumped by pg_dump version 9.5.25

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.events DROP CONSTRAINT fk_rails_ff93bdc68d;
ALTER TABLE ONLY public.works DROP CONSTRAINT fk_rails_f466c606bb;
ALTER TABLE ONLY public.absences DROP CONSTRAINT fk_rails_f4043bdcfe;
ALTER TABLE ONLY public.messages DROP CONSTRAINT fk_rails_db7ace0f80;
ALTER TABLE ONLY public.jours DROP CONSTRAINT fk_rails_d9f2bb24dc;
ALTER TABLE ONLY public.blog_messages DROP CONSTRAINT fk_rails_c49356f00a;
ALTER TABLE ONLY public.blog_messages DROP CONSTRAINT fk_rails_c123c2783a;
ALTER TABLE ONLY public.works DROP CONSTRAINT fk_rails_a5b6ca6089;
ALTER TABLE ONLY public.messages DROP CONSTRAINT fk_rails_a43ca7dd41;
ALTER TABLE ONLY public.fermetures DROP CONSTRAINT fk_rails_a2c55913ce;
ALTER TABLE ONLY public.blog_responses DROP CONSTRAINT fk_rails_a290f1a5b1;
ALTER TABLE ONLY public.utilisateurs DROP CONSTRAINT fk_rails_9189f91c53;
ALTER TABLE ONLY public.blog_messages DROP CONSTRAINT fk_rails_79cb1f4ea9;
ALTER TABLE ONLY public.demande_conges DROP CONSTRAINT fk_rails_729cf6104d;
ALTER TABLE ONLY public.jours DROP CONSTRAINT fk_rails_661d514733;
ALTER TABLE ONLY public.works DROP CONSTRAINT fk_rails_6193f61ffa;
ALTER TABLE ONLY public.blog_responses DROP CONSTRAINT fk_rails_567257db3c;
ALTER TABLE ONLY public.working_lists DROP CONSTRAINT fk_rails_47a9f48ec7;
ALTER TABLE ONLY public.bug_repports DROP CONSTRAINT fk_rails_2e875501e3;
ALTER TABLE ONLY public.utilisateurs DROP CONSTRAINT fk_rails_2e57212d6a;
ALTER TABLE ONLY public.utilisateurs DROP CONSTRAINT fk_rails_2d7f78bc98;
ALTER TABLE ONLY public.services DROP CONSTRAINT fk_rails_29ee5530cc;
ALTER TABLE ONLY public.ajouts DROP CONSTRAINT fk_rails_27ad140c06;
ALTER TABLE ONLY public.working_lists DROP CONSTRAINT fk_rails_024b0deb6b;
ALTER TABLE ONLY public.absences DROP CONSTRAINT fk_rails_01905dceab;
DROP INDEX public.index_works_on_service_id;
DROP INDEX public.index_works_on_groupe_id;
DROP INDEX public.index_works_on_classe_id;
DROP INDEX public.index_working_lists_on_work_id;
DROP INDEX public.index_working_lists_on_jour_id;
DROP INDEX public.index_utilisateurs_on_user_id;
DROP INDEX public.index_utilisateurs_on_service_id;
DROP INDEX public.index_utilisateurs_on_groupe_id;
DROP INDEX public.index_users_on_reset_password_token;
DROP INDEX public.index_users_on_email;
DROP INDEX public.index_services_on_lieu_id;
DROP INDEX public.index_messages_on_utilisateur_id;
DROP INDEX public.index_messages_on_service_id;
DROP INDEX public.index_jours_on_utilisateur_id;
DROP INDEX public.index_jours_on_service_id;
DROP INDEX public.index_fermetures_on_service_id;
DROP INDEX public.index_events_on_service_id;
DROP INDEX public.index_demande_conges_on_utilisateur_id;
DROP INDEX public.index_bug_repports_on_utilisateur_id;
DROP INDEX public.index_blog_responses_on_utilisateur_id;
DROP INDEX public.index_blog_responses_on_blog_message_id;
DROP INDEX public.index_blog_messages_on_utilisateur_id;
DROP INDEX public.index_blog_messages_on_service_id;
DROP INDEX public.index_blog_messages_on_blog_category_id;
DROP INDEX public.index_ajouts_on_utilisateur_id;
DROP INDEX public.index_absences_on_utilisateur_id;
DROP INDEX public.index_absences_on_type_absence_id;
ALTER TABLE ONLY public.works DROP CONSTRAINT works_pkey;
ALTER TABLE ONLY public.working_lists DROP CONSTRAINT working_lists_pkey;
ALTER TABLE ONLY public.utilisateurs DROP CONSTRAINT utilisateurs_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.type_absences DROP CONSTRAINT type_absences_pkey;
ALTER TABLE ONLY public.templates DROP CONSTRAINT templates_pkey;
ALTER TABLE ONLY public.services DROP CONSTRAINT services_pkey;
ALTER TABLE ONLY public.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY public.messages DROP CONSTRAINT messages_pkey;
ALTER TABLE ONLY public.logs DROP CONSTRAINT logs_pkey;
ALTER TABLE ONLY public.lieus DROP CONSTRAINT lieus_pkey;
ALTER TABLE ONLY public.konfigurations DROP CONSTRAINT konfigurations_pkey;
ALTER TABLE ONLY public.jours DROP CONSTRAINT jours_pkey;
ALTER TABLE ONLY public.groupes DROP CONSTRAINT groupes_pkey;
ALTER TABLE ONLY public.fermetures DROP CONSTRAINT fermetures_pkey;
ALTER TABLE ONLY public.events DROP CONSTRAINT events_pkey;
ALTER TABLE ONLY public.demande_conges DROP CONSTRAINT demande_conges_pkey;
ALTER TABLE ONLY public.configurations DROP CONSTRAINT configurations_pkey;
ALTER TABLE ONLY public.classes DROP CONSTRAINT classes_pkey;
ALTER TABLE ONLY public.bug_repports DROP CONSTRAINT bug_repports_pkey;
ALTER TABLE ONLY public.blog_responses DROP CONSTRAINT blog_responses_pkey;
ALTER TABLE ONLY public.blog_messages DROP CONSTRAINT blog_messages_pkey;
ALTER TABLE ONLY public.blog_categories DROP CONSTRAINT blog_categories_pkey;
ALTER TABLE ONLY public.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE ONLY public.ajouts DROP CONSTRAINT ajouts_pkey;
ALTER TABLE ONLY public.absences DROP CONSTRAINT absences_pkey;
ALTER TABLE public.works ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.working_lists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.utilisateurs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.type_absences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.services ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.lieus ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.konfigurations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.jours ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.groupes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fermetures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.demande_conges ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.configurations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.classes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bug_repports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_responses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ajouts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.absences ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.works_id_seq;
DROP TABLE public.works;
DROP SEQUENCE public.working_lists_id_seq;
DROP TABLE public.working_lists;
DROP SEQUENCE public.utilisateurs_id_seq;
DROP TABLE public.utilisateurs;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.type_absences_id_seq;
DROP TABLE public.type_absences;
DROP SEQUENCE public.templates_id_seq;
DROP TABLE public.templates;
DROP SEQUENCE public.services_id_seq;
DROP TABLE public.services;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.messages_id_seq;
DROP TABLE public.messages;
DROP SEQUENCE public.logs_id_seq;
DROP TABLE public.logs;
DROP SEQUENCE public.lieus_id_seq;
DROP TABLE public.lieus;
DROP SEQUENCE public.konfigurations_id_seq;
DROP TABLE public.konfigurations;
DROP SEQUENCE public.jours_id_seq;
DROP TABLE public.jours;
DROP SEQUENCE public.groupes_id_seq;
DROP TABLE public.groupes;
DROP SEQUENCE public.fermetures_id_seq;
DROP TABLE public.fermetures;
DROP SEQUENCE public.events_id_seq;
DROP TABLE public.events;
DROP SEQUENCE public.demande_conges_id_seq;
DROP TABLE public.demande_conges;
DROP SEQUENCE public.configurations_id_seq;
DROP TABLE public.configurations;
DROP SEQUENCE public.classes_id_seq;
DROP TABLE public.classes;
DROP SEQUENCE public.bug_repports_id_seq;
DROP TABLE public.bug_repports;
DROP SEQUENCE public.blog_responses_id_seq;
DROP TABLE public.blog_responses;
DROP SEQUENCE public.blog_messages_id_seq;
DROP TABLE public.blog_messages;
DROP SEQUENCE public.blog_categories_id_seq;
DROP TABLE public.blog_categories;
DROP TABLE public.ar_internal_metadata;
DROP SEQUENCE public.ajouts_id_seq;
DROP TABLE public.ajouts;
DROP SEQUENCE public.absences_id_seq;
DROP TABLE public.absences;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: salim
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO salim;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: salim
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: absences; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.absences (
    id bigint NOT NULL,
    type_absence_id bigint,
    utilisateur_id bigint,
    date date,
    date_fin date,
    remarque character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    accord boolean,
    halfday boolean
);


ALTER TABLE public.absences OWNER TO salim;

--
-- Name: absences_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.absences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.absences_id_seq OWNER TO salim;

--
-- Name: absences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.absences_id_seq OWNED BY public.absences.id;


--
-- Name: ajouts; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.ajouts (
    id bigint NOT NULL,
    utilisateur_id bigint,
    date date,
    am_pm boolean,
    work1 integer,
    work2 integer,
    work3 integer,
    work4 integer,
    work5 integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ajouts OWNER TO salim;

--
-- Name: ajouts_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.ajouts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ajouts_id_seq OWNER TO salim;

--
-- Name: ajouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.ajouts_id_seq OWNED BY public.ajouts.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO salim;

--
-- Name: blog_categories; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.blog_categories (
    id bigint NOT NULL,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.blog_categories OWNER TO salim;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.blog_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_categories_id_seq OWNER TO salim;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.blog_categories_id_seq OWNED BY public.blog_categories.id;


--
-- Name: blog_messages; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.blog_messages (
    id bigint NOT NULL,
    utilisateur_id bigint,
    blog_category_id bigint,
    service_id bigint,
    title character varying,
    keywords character varying,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    date timestamp without time zone,
    groupe integer,
    classe integer,
    logbook boolean,
    reviewed boolean,
    reviewer integer
);


ALTER TABLE public.blog_messages OWNER TO salim;

--
-- Name: blog_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.blog_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_messages_id_seq OWNER TO salim;

--
-- Name: blog_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.blog_messages_id_seq OWNED BY public.blog_messages.id;


--
-- Name: blog_responses; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.blog_responses (
    id bigint NOT NULL,
    utilisateur_id bigint,
    blog_message_id bigint,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.blog_responses OWNER TO salim;

--
-- Name: blog_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.blog_responses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_responses_id_seq OWNER TO salim;

--
-- Name: blog_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.blog_responses_id_seq OWNED BY public.blog_responses.id;


--
-- Name: bug_repports; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.bug_repports (
    id bigint NOT NULL,
    utilisateur_id bigint,
    date date,
    nom character varying,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    status character varying
);


ALTER TABLE public.bug_repports OWNER TO salim;

--
-- Name: bug_repports_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.bug_repports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bug_repports_id_seq OWNER TO salim;

--
-- Name: bug_repports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.bug_repports_id_seq OWNED BY public.bug_repports.id;


--
-- Name: classes; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.classes (
    id bigint NOT NULL,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.classes OWNER TO salim;

--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.classes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.classes_id_seq OWNER TO salim;

--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.classes.id;


--
-- Name: configurations; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.configurations (
    id bigint NOT NULL,
    key character varying,
    value character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.configurations OWNER TO salim;

--
-- Name: configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.configurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.configurations_id_seq OWNER TO salim;

--
-- Name: configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.configurations_id_seq OWNED BY public.configurations.id;


--
-- Name: demande_conges; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.demande_conges (
    id bigint NOT NULL,
    date date,
    date_fin date,
    date_demande date,
    utilisateur_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.demande_conges OWNER TO salim;

--
-- Name: demande_conges_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.demande_conges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.demande_conges_id_seq OWNER TO salim;

--
-- Name: demande_conges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.demande_conges_id_seq OWNED BY public.demande_conges.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    nom character varying,
    date date,
    note character varying,
    service_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.events OWNER TO salim;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_id_seq OWNER TO salim;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: fermetures; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.fermetures (
    id bigint NOT NULL,
    nom character varying,
    date date,
    date_fin date,
    note character varying,
    service_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.fermetures OWNER TO salim;

--
-- Name: fermetures_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.fermetures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fermetures_id_seq OWNER TO salim;

--
-- Name: fermetures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.fermetures_id_seq OWNED BY public.fermetures.id;


--
-- Name: groupes; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.groupes (
    id bigint NOT NULL,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.groupes OWNER TO salim;

--
-- Name: groupes_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.groupes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groupes_id_seq OWNER TO salim;

--
-- Name: groupes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.groupes_id_seq OWNED BY public.groupes.id;


--
-- Name: jours; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.jours (
    id bigint NOT NULL,
    utilisateur_id bigint,
    service_id bigint,
    numero_semaine character varying,
    date date,
    numero_jour integer,
    am_pm boolean,
    note character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.jours OWNER TO salim;

--
-- Name: jours_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.jours_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jours_id_seq OWNER TO salim;

--
-- Name: jours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.jours_id_seq OWNED BY public.jours.id;


--
-- Name: konfigurations; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.konfigurations (
    id bigint NOT NULL,
    key character varying,
    value character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.konfigurations OWNER TO salim;

--
-- Name: konfigurations_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.konfigurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.konfigurations_id_seq OWNER TO salim;

--
-- Name: konfigurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.konfigurations_id_seq OWNED BY public.konfigurations.id;


--
-- Name: lieus; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.lieus (
    id bigint NOT NULL,
    nom character varying,
    adresse text,
    phone character varying,
    note character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.lieus OWNER TO salim;

--
-- Name: lieus_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.lieus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lieus_id_seq OWNER TO salim;

--
-- Name: lieus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.lieus_id_seq OWNED BY public.lieus.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.logs (
    id bigint NOT NULL,
    date timestamp without time zone,
    adresse character varying,
    utilisateur_id integer,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.logs OWNER TO salim;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_id_seq OWNER TO salim;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    service_id bigint,
    note character varying,
    date date,
    date_fin date,
    utilisateur_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.messages OWNER TO salim;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO salim;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO salim;

--
-- Name: services; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.services (
    id bigint NOT NULL,
    lieu_id bigint,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.services OWNER TO salim;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_id_seq OWNER TO salim;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: templates; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.templates (
    id bigint NOT NULL,
    am_pm1 boolean,
    work1_1 integer,
    work1_2 integer,
    work1_3 integer,
    work1_4 integer,
    work1_5 integer,
    am_pm2 boolean,
    work2_1 integer,
    work2_2 integer,
    work2_3 integer,
    work2_4 integer,
    work2_5 integer,
    am_pm3 boolean,
    work3_2 integer,
    work3_3 integer,
    work3_4 integer,
    work3_5 integer,
    am_pm4 boolean,
    work4_1 integer,
    work4_2 integer,
    work4_3 integer,
    work4_4 integer,
    work4_5 integer,
    am_pm5 boolean,
    work5_1 integer,
    work5_2 integer,
    work5_3 integer,
    work5_4 integer,
    work5_5 integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    nom character varying,
    description character varying,
    service_id integer,
    work3_1 integer
);


ALTER TABLE public.templates OWNER TO salim;

--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.templates_id_seq OWNER TO salim;

--
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.templates_id_seq OWNED BY public.templates.id;


--
-- Name: type_absences; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.type_absences (
    id bigint NOT NULL,
    code character varying,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.type_absences OWNER TO salim;

--
-- Name: type_absences_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.type_absences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_absences_id_seq OWNER TO salim;

--
-- Name: type_absences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.type_absences_id_seq OWNED BY public.type_absences.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    admin boolean,
    last_connection timestamp without time zone
);


ALTER TABLE public.users OWNER TO salim;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO salim;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: utilisateurs; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.utilisateurs (
    id bigint NOT NULL,
    groupe_id bigint,
    service_id bigint,
    prenom character varying,
    nom character varying,
    email character varying,
    phone character varying,
    gsm character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id bigint,
    admin boolean,
    last_connection timestamp without time zone
);


ALTER TABLE public.utilisateurs OWNER TO salim;

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.utilisateurs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.utilisateurs_id_seq OWNER TO salim;

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.utilisateurs_id_seq OWNED BY public.utilisateurs.id;


--
-- Name: working_lists; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.working_lists (
    id bigint NOT NULL,
    work_id bigint,
    jour_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.working_lists OWNER TO salim;

--
-- Name: working_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.working_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.working_lists_id_seq OWNER TO salim;

--
-- Name: working_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.working_lists_id_seq OWNED BY public.working_lists.id;


--
-- Name: works; Type: TABLE; Schema: public; Owner: salim
--

CREATE TABLE public.works (
    id bigint NOT NULL,
    groupe_id bigint,
    classe_id bigint,
    service_id bigint,
    nom character varying,
    code character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    mark boolean,
    early_value integer
);


ALTER TABLE public.works OWNER TO salim;

--
-- Name: works_id_seq; Type: SEQUENCE; Schema: public; Owner: salim
--

CREATE SEQUENCE public.works_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.works_id_seq OWNER TO salim;

--
-- Name: works_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: salim
--

ALTER SEQUENCE public.works_id_seq OWNED BY public.works.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.absences ALTER COLUMN id SET DEFAULT nextval('public.absences_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.ajouts ALTER COLUMN id SET DEFAULT nextval('public.ajouts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_categories ALTER COLUMN id SET DEFAULT nextval('public.blog_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_messages ALTER COLUMN id SET DEFAULT nextval('public.blog_messages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_responses ALTER COLUMN id SET DEFAULT nextval('public.blog_responses_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.bug_repports ALTER COLUMN id SET DEFAULT nextval('public.bug_repports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.classes ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.configurations ALTER COLUMN id SET DEFAULT nextval('public.configurations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.demande_conges ALTER COLUMN id SET DEFAULT nextval('public.demande_conges_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.fermetures ALTER COLUMN id SET DEFAULT nextval('public.fermetures_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.groupes ALTER COLUMN id SET DEFAULT nextval('public.groupes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.jours ALTER COLUMN id SET DEFAULT nextval('public.jours_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.konfigurations ALTER COLUMN id SET DEFAULT nextval('public.konfigurations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.lieus ALTER COLUMN id SET DEFAULT nextval('public.lieus_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.templates ALTER COLUMN id SET DEFAULT nextval('public.templates_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.type_absences ALTER COLUMN id SET DEFAULT nextval('public.type_absences_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.utilisateurs ALTER COLUMN id SET DEFAULT nextval('public.utilisateurs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.working_lists ALTER COLUMN id SET DEFAULT nextval('public.working_lists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.works ALTER COLUMN id SET DEFAULT nextval('public.works_id_seq'::regclass);


--
-- Data for Name: absences; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.absences (id, type_absence_id, utilisateur_id, date, date_fin, remarque, created_at, updated_at, accord, halfday) FROM stdin;
\.
COPY public.absences (id, type_absence_id, utilisateur_id, date, date_fin, remarque, created_at, updated_at, accord, halfday) FROM '$$PATH$$/2440.dat';

--
-- Name: absences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.absences_id_seq', 190, true);


--
-- Data for Name: ajouts; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.ajouts (id, utilisateur_id, date, am_pm, work1, work2, work3, work4, work5, created_at, updated_at) FROM stdin;
\.
COPY public.ajouts (id, utilisateur_id, date, am_pm, work1, work2, work3, work4, work5, created_at, updated_at) FROM '$$PATH$$/2442.dat';

--
-- Name: ajouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.ajouts_id_seq', 1568, true);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/2444.dat';

--
-- Data for Name: blog_categories; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.blog_categories (id, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.blog_categories (id, nom, description, created_at, updated_at) FROM '$$PATH$$/2445.dat';

--
-- Name: blog_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.blog_categories_id_seq', 5, true);


--
-- Data for Name: blog_messages; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.blog_messages (id, utilisateur_id, blog_category_id, service_id, title, keywords, description, created_at, updated_at, date, groupe, classe, logbook, reviewed, reviewer) FROM stdin;
\.
COPY public.blog_messages (id, utilisateur_id, blog_category_id, service_id, title, keywords, description, created_at, updated_at, date, groupe, classe, logbook, reviewed, reviewer) FROM '$$PATH$$/2447.dat';

--
-- Name: blog_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.blog_messages_id_seq', 19, true);


--
-- Data for Name: blog_responses; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.blog_responses (id, utilisateur_id, blog_message_id, description, created_at, updated_at) FROM stdin;
\.
COPY public.blog_responses (id, utilisateur_id, blog_message_id, description, created_at, updated_at) FROM '$$PATH$$/2449.dat';

--
-- Name: blog_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.blog_responses_id_seq', 4, true);


--
-- Data for Name: bug_repports; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.bug_repports (id, utilisateur_id, date, nom, description, created_at, updated_at, status) FROM stdin;
\.
COPY public.bug_repports (id, utilisateur_id, date, nom, description, created_at, updated_at, status) FROM '$$PATH$$/2451.dat';

--
-- Name: bug_repports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.bug_repports_id_seq', 5, true);


--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.classes (id, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.classes (id, nom, description, created_at, updated_at) FROM '$$PATH$$/2453.dat';

--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.classes_id_seq', 4, true);


--
-- Data for Name: configurations; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.configurations (id, key, value, description, created_at, updated_at) FROM stdin;
\.
COPY public.configurations (id, key, value, description, created_at, updated_at) FROM '$$PATH$$/2489.dat';

--
-- Name: configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.configurations_id_seq', 1, false);


--
-- Data for Name: demande_conges; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.demande_conges (id, date, date_fin, date_demande, utilisateur_id, created_at, updated_at) FROM stdin;
\.
COPY public.demande_conges (id, date, date_fin, date_demande, utilisateur_id, created_at, updated_at) FROM '$$PATH$$/2455.dat';

--
-- Name: demande_conges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.demande_conges_id_seq', 1, false);


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.events (id, nom, date, note, service_id, created_at, updated_at) FROM stdin;
\.
COPY public.events (id, nom, date, note, service_id, created_at, updated_at) FROM '$$PATH$$/2457.dat';

--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.events_id_seq', 18, true);


--
-- Data for Name: fermetures; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.fermetures (id, nom, date, date_fin, note, service_id, created_at, updated_at) FROM stdin;
\.
COPY public.fermetures (id, nom, date, date_fin, note, service_id, created_at, updated_at) FROM '$$PATH$$/2459.dat';

--
-- Name: fermetures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.fermetures_id_seq', 15, true);


--
-- Data for Name: groupes; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.groupes (id, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.groupes (id, nom, description, created_at, updated_at) FROM '$$PATH$$/2461.dat';

--
-- Name: groupes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.groupes_id_seq', 12, true);


--
-- Data for Name: jours; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.jours (id, utilisateur_id, service_id, numero_semaine, date, numero_jour, am_pm, note, created_at, updated_at) FROM stdin;
\.
COPY public.jours (id, utilisateur_id, service_id, numero_semaine, date, numero_jour, am_pm, note, created_at, updated_at) FROM '$$PATH$$/2463.dat';

--
-- Name: jours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.jours_id_seq', 1258, true);


--
-- Data for Name: konfigurations; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.konfigurations (id, key, value, description, created_at, updated_at) FROM stdin;
\.
COPY public.konfigurations (id, key, value, description, created_at, updated_at) FROM '$$PATH$$/2487.dat';

--
-- Name: konfigurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.konfigurations_id_seq', 11, true);


--
-- Data for Name: lieus; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.lieus (id, nom, adresse, phone, note, created_at, updated_at) FROM stdin;
\.
COPY public.lieus (id, nom, adresse, phone, note, created_at, updated_at) FROM '$$PATH$$/2465.dat';

--
-- Name: lieus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.lieus_id_seq', 2, true);


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.logs (id, date, adresse, utilisateur_id, description, created_at, updated_at) FROM stdin;
\.
COPY public.logs (id, date, adresse, utilisateur_id, description, created_at, updated_at) FROM '$$PATH$$/2467.dat';

--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.logs_id_seq', 42272, true);


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.messages (id, service_id, note, date, date_fin, utilisateur_id, created_at, updated_at) FROM stdin;
\.
COPY public.messages (id, service_id, note, date, date_fin, utilisateur_id, created_at, updated_at) FROM '$$PATH$$/2469.dat';

--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.messages_id_seq', 4, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/2471.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.services (id, lieu_id, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.services (id, lieu_id, nom, description, created_at, updated_at) FROM '$$PATH$$/2472.dat';

--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.services_id_seq', 3, true);


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.templates (id, am_pm1, work1_1, work1_2, work1_3, work1_4, work1_5, am_pm2, work2_1, work2_2, work2_3, work2_4, work2_5, am_pm3, work3_2, work3_3, work3_4, work3_5, am_pm4, work4_1, work4_2, work4_3, work4_4, work4_5, am_pm5, work5_1, work5_2, work5_3, work5_4, work5_5, created_at, updated_at, nom, description, service_id, work3_1) FROM stdin;
\.
COPY public.templates (id, am_pm1, work1_1, work1_2, work1_3, work1_4, work1_5, am_pm2, work2_1, work2_2, work2_3, work2_4, work2_5, am_pm3, work3_2, work3_3, work3_4, work3_5, am_pm4, work4_1, work4_2, work4_3, work4_4, work4_5, am_pm5, work5_1, work5_2, work5_3, work5_4, work5_5, created_at, updated_at, nom, description, service_id, work3_1) FROM '$$PATH$$/2474.dat';

--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.templates_id_seq', 3, true);


--
-- Data for Name: type_absences; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.type_absences (id, code, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.type_absences (id, code, nom, description, created_at, updated_at) FROM '$$PATH$$/2476.dat';

--
-- Name: type_absences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.type_absences_id_seq', 3, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at, admin, last_connection) FROM stdin;
\.
COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at, admin, last_connection) FROM '$$PATH$$/2478.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.users_id_seq', 28, true);


--
-- Data for Name: utilisateurs; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.utilisateurs (id, groupe_id, service_id, prenom, nom, email, phone, gsm, created_at, updated_at, user_id, admin, last_connection) FROM stdin;
\.
COPY public.utilisateurs (id, groupe_id, service_id, prenom, nom, email, phone, gsm, created_at, updated_at, user_id, admin, last_connection) FROM '$$PATH$$/2480.dat';

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.utilisateurs_id_seq', 30, true);


--
-- Data for Name: working_lists; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.working_lists (id, work_id, jour_id, created_at, updated_at) FROM stdin;
\.
COPY public.working_lists (id, work_id, jour_id, created_at, updated_at) FROM '$$PATH$$/2482.dat';

--
-- Name: working_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.working_lists_id_seq', 2203, true);


--
-- Data for Name: works; Type: TABLE DATA; Schema: public; Owner: salim
--

COPY public.works (id, groupe_id, classe_id, service_id, nom, code, description, created_at, updated_at, mark, early_value) FROM stdin;
\.
COPY public.works (id, groupe_id, classe_id, service_id, nom, code, description, created_at, updated_at, mark, early_value) FROM '$$PATH$$/2484.dat';

--
-- Name: works_id_seq; Type: SEQUENCE SET; Schema: public; Owner: salim
--

SELECT pg_catalog.setval('public.works_id_seq', 41, true);


--
-- Name: absences_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.absences
    ADD CONSTRAINT absences_pkey PRIMARY KEY (id);


--
-- Name: ajouts_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.ajouts
    ADD CONSTRAINT ajouts_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: blog_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_messages
    ADD CONSTRAINT blog_messages_pkey PRIMARY KEY (id);


--
-- Name: blog_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_responses
    ADD CONSTRAINT blog_responses_pkey PRIMARY KEY (id);


--
-- Name: bug_repports_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.bug_repports
    ADD CONSTRAINT bug_repports_pkey PRIMARY KEY (id);


--
-- Name: classes_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.configurations
    ADD CONSTRAINT configurations_pkey PRIMARY KEY (id);


--
-- Name: demande_conges_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.demande_conges
    ADD CONSTRAINT demande_conges_pkey PRIMARY KEY (id);


--
-- Name: events_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: fermetures_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.fermetures
    ADD CONSTRAINT fermetures_pkey PRIMARY KEY (id);


--
-- Name: groupes_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.groupes
    ADD CONSTRAINT groupes_pkey PRIMARY KEY (id);


--
-- Name: jours_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.jours
    ADD CONSTRAINT jours_pkey PRIMARY KEY (id);


--
-- Name: konfigurations_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.konfigurations
    ADD CONSTRAINT konfigurations_pkey PRIMARY KEY (id);


--
-- Name: lieus_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.lieus
    ADD CONSTRAINT lieus_pkey PRIMARY KEY (id);


--
-- Name: logs_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: messages_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: services_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: templates_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: type_absences_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.type_absences
    ADD CONSTRAINT type_absences_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: utilisateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT utilisateurs_pkey PRIMARY KEY (id);


--
-- Name: working_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.working_lists
    ADD CONSTRAINT working_lists_pkey PRIMARY KEY (id);


--
-- Name: works_pkey; Type: CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_pkey PRIMARY KEY (id);


--
-- Name: index_absences_on_type_absence_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_absences_on_type_absence_id ON public.absences USING btree (type_absence_id);


--
-- Name: index_absences_on_utilisateur_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_absences_on_utilisateur_id ON public.absences USING btree (utilisateur_id);


--
-- Name: index_ajouts_on_utilisateur_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_ajouts_on_utilisateur_id ON public.ajouts USING btree (utilisateur_id);


--
-- Name: index_blog_messages_on_blog_category_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_blog_messages_on_blog_category_id ON public.blog_messages USING btree (blog_category_id);


--
-- Name: index_blog_messages_on_service_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_blog_messages_on_service_id ON public.blog_messages USING btree (service_id);


--
-- Name: index_blog_messages_on_utilisateur_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_blog_messages_on_utilisateur_id ON public.blog_messages USING btree (utilisateur_id);


--
-- Name: index_blog_responses_on_blog_message_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_blog_responses_on_blog_message_id ON public.blog_responses USING btree (blog_message_id);


--
-- Name: index_blog_responses_on_utilisateur_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_blog_responses_on_utilisateur_id ON public.blog_responses USING btree (utilisateur_id);


--
-- Name: index_bug_repports_on_utilisateur_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_bug_repports_on_utilisateur_id ON public.bug_repports USING btree (utilisateur_id);


--
-- Name: index_demande_conges_on_utilisateur_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_demande_conges_on_utilisateur_id ON public.demande_conges USING btree (utilisateur_id);


--
-- Name: index_events_on_service_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_events_on_service_id ON public.events USING btree (service_id);


--
-- Name: index_fermetures_on_service_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_fermetures_on_service_id ON public.fermetures USING btree (service_id);


--
-- Name: index_jours_on_service_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_jours_on_service_id ON public.jours USING btree (service_id);


--
-- Name: index_jours_on_utilisateur_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_jours_on_utilisateur_id ON public.jours USING btree (utilisateur_id);


--
-- Name: index_messages_on_service_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_messages_on_service_id ON public.messages USING btree (service_id);


--
-- Name: index_messages_on_utilisateur_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_messages_on_utilisateur_id ON public.messages USING btree (utilisateur_id);


--
-- Name: index_services_on_lieu_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_services_on_lieu_id ON public.services USING btree (lieu_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: salim
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: salim
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: index_utilisateurs_on_groupe_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_utilisateurs_on_groupe_id ON public.utilisateurs USING btree (groupe_id);


--
-- Name: index_utilisateurs_on_service_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_utilisateurs_on_service_id ON public.utilisateurs USING btree (service_id);


--
-- Name: index_utilisateurs_on_user_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_utilisateurs_on_user_id ON public.utilisateurs USING btree (user_id);


--
-- Name: index_working_lists_on_jour_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_working_lists_on_jour_id ON public.working_lists USING btree (jour_id);


--
-- Name: index_working_lists_on_work_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_working_lists_on_work_id ON public.working_lists USING btree (work_id);


--
-- Name: index_works_on_classe_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_works_on_classe_id ON public.works USING btree (classe_id);


--
-- Name: index_works_on_groupe_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_works_on_groupe_id ON public.works USING btree (groupe_id);


--
-- Name: index_works_on_service_id; Type: INDEX; Schema: public; Owner: salim
--

CREATE INDEX index_works_on_service_id ON public.works USING btree (service_id);


--
-- Name: fk_rails_01905dceab; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.absences
    ADD CONSTRAINT fk_rails_01905dceab FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: fk_rails_024b0deb6b; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.working_lists
    ADD CONSTRAINT fk_rails_024b0deb6b FOREIGN KEY (work_id) REFERENCES public.works(id);


--
-- Name: fk_rails_27ad140c06; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.ajouts
    ADD CONSTRAINT fk_rails_27ad140c06 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: fk_rails_29ee5530cc; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT fk_rails_29ee5530cc FOREIGN KEY (lieu_id) REFERENCES public.lieus(id);


--
-- Name: fk_rails_2d7f78bc98; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT fk_rails_2d7f78bc98 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: fk_rails_2e57212d6a; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT fk_rails_2e57212d6a FOREIGN KEY (groupe_id) REFERENCES public.groupes(id);


--
-- Name: fk_rails_2e875501e3; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.bug_repports
    ADD CONSTRAINT fk_rails_2e875501e3 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: fk_rails_47a9f48ec7; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.working_lists
    ADD CONSTRAINT fk_rails_47a9f48ec7 FOREIGN KEY (jour_id) REFERENCES public.jours(id);


--
-- Name: fk_rails_567257db3c; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_responses
    ADD CONSTRAINT fk_rails_567257db3c FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: fk_rails_6193f61ffa; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_rails_6193f61ffa FOREIGN KEY (groupe_id) REFERENCES public.groupes(id);


--
-- Name: fk_rails_661d514733; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.jours
    ADD CONSTRAINT fk_rails_661d514733 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: fk_rails_729cf6104d; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.demande_conges
    ADD CONSTRAINT fk_rails_729cf6104d FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: fk_rails_79cb1f4ea9; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_messages
    ADD CONSTRAINT fk_rails_79cb1f4ea9 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: fk_rails_9189f91c53; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT fk_rails_9189f91c53 FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: fk_rails_a290f1a5b1; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_responses
    ADD CONSTRAINT fk_rails_a290f1a5b1 FOREIGN KEY (blog_message_id) REFERENCES public.blog_messages(id);


--
-- Name: fk_rails_a2c55913ce; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.fermetures
    ADD CONSTRAINT fk_rails_a2c55913ce FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: fk_rails_a43ca7dd41; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_a43ca7dd41 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: fk_rails_a5b6ca6089; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_rails_a5b6ca6089 FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: fk_rails_c123c2783a; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_messages
    ADD CONSTRAINT fk_rails_c123c2783a FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: fk_rails_c49356f00a; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.blog_messages
    ADD CONSTRAINT fk_rails_c49356f00a FOREIGN KEY (blog_category_id) REFERENCES public.blog_categories(id);


--
-- Name: fk_rails_d9f2bb24dc; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.jours
    ADD CONSTRAINT fk_rails_d9f2bb24dc FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: fk_rails_db7ace0f80; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_db7ace0f80 FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: fk_rails_f4043bdcfe; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.absences
    ADD CONSTRAINT fk_rails_f4043bdcfe FOREIGN KEY (type_absence_id) REFERENCES public.type_absences(id);


--
-- Name: fk_rails_f466c606bb; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_rails_f466c606bb FOREIGN KEY (classe_id) REFERENCES public.classes(id);


--
-- Name: fk_rails_ff93bdc68d; Type: FK CONSTRAINT; Schema: public; Owner: salim
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT fk_rails_ff93bdc68d FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- PostgreSQL database dump complete
--

