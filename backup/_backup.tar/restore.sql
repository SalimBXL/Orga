--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Ubuntu 13.4-4.pgdg18.04+1)
-- Dumped by pg_dump version 13.4 (Ubuntu 13.4-4.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "MyDataBase_development";
--
-- Name: MyDataBase_development; Type: DATABASE; Schema: -; Owner: orga
--

CREATE DATABASE "MyDataBase_development" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'fr_BE.UTF-8';


ALTER DATABASE "MyDataBase_development" OWNER TO orga;

\connect "MyDataBase_development"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: absences; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.absences (
    id bigint NOT NULL,
    type_absence_id bigint,
    utilisateur_id bigint,
    date date,
    date_fin date,
    remarque character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    accord boolean,
    halfday boolean
);


ALTER TABLE public.absences OWNER TO orga;

--
-- Name: absences_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.absences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.absences_id_seq OWNER TO orga;

--
-- Name: absences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.absences_id_seq OWNED BY public.absences.id;


--
-- Name: ajouts; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.ajouts (
    id bigint NOT NULL,
    utilisateur_id bigint,
    date date,
    am_pm boolean,
    work1 integer,
    work2 integer,
    work3 integer,
    work4 integer,
    work5 integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ajouts OWNER TO orga;

--
-- Name: ajouts_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.ajouts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ajouts_id_seq OWNER TO orga;

--
-- Name: ajouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.ajouts_id_seq OWNED BY public.ajouts.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO orga;

--
-- Name: blog_categories; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.blog_categories (
    id bigint NOT NULL,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.blog_categories OWNER TO orga;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.blog_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_categories_id_seq OWNER TO orga;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.blog_categories_id_seq OWNED BY public.blog_categories.id;


--
-- Name: blog_messages; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.blog_messages (
    id bigint NOT NULL,
    utilisateur_id bigint,
    blog_category_id bigint,
    service_id bigint,
    title character varying,
    keywords character varying,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    date timestamp without time zone,
    groupe integer,
    classe integer,
    logbook boolean,
    reviewed boolean,
    reviewer integer
);


ALTER TABLE public.blog_messages OWNER TO orga;

--
-- Name: blog_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.blog_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_messages_id_seq OWNER TO orga;

--
-- Name: blog_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.blog_messages_id_seq OWNED BY public.blog_messages.id;


--
-- Name: blog_responses; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.blog_responses (
    id bigint NOT NULL,
    utilisateur_id bigint,
    blog_message_id bigint,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.blog_responses OWNER TO orga;

--
-- Name: blog_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.blog_responses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_responses_id_seq OWNER TO orga;

--
-- Name: blog_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.blog_responses_id_seq OWNED BY public.blog_responses.id;


--
-- Name: bug_repports; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.bug_repports (
    id bigint NOT NULL,
    utilisateur_id bigint,
    date date,
    nom character varying,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    status character varying
);


ALTER TABLE public.bug_repports OWNER TO orga;

--
-- Name: bug_repports_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.bug_repports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bug_repports_id_seq OWNER TO orga;

--
-- Name: bug_repports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.bug_repports_id_seq OWNED BY public.bug_repports.id;


--
-- Name: classes; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.classes (
    id bigint NOT NULL,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.classes OWNER TO orga;

--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.classes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.classes_id_seq OWNER TO orga;

--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.classes.id;


--
-- Name: configurations; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.configurations (
    id bigint NOT NULL,
    key character varying,
    value character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.configurations OWNER TO orga;

--
-- Name: configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.configurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.configurations_id_seq OWNER TO orga;

--
-- Name: configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.configurations_id_seq OWNED BY public.configurations.id;


--
-- Name: demande_conges; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.demande_conges (
    id bigint NOT NULL,
    date date,
    date_fin date,
    date_demande date,
    utilisateur_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.demande_conges OWNER TO orga;

--
-- Name: demande_conges_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.demande_conges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.demande_conges_id_seq OWNER TO orga;

--
-- Name: demande_conges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.demande_conges_id_seq OWNED BY public.demande_conges.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    nom character varying,
    date date,
    note character varying,
    service_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.events OWNER TO orga;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_id_seq OWNER TO orga;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: fermetures; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.fermetures (
    id bigint NOT NULL,
    nom character varying,
    date date,
    date_fin date,
    note character varying,
    service_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.fermetures OWNER TO orga;

--
-- Name: fermetures_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.fermetures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fermetures_id_seq OWNER TO orga;

--
-- Name: fermetures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.fermetures_id_seq OWNED BY public.fermetures.id;


--
-- Name: groupes; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.groupes (
    id bigint NOT NULL,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.groupes OWNER TO orga;

--
-- Name: groupes_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.groupes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groupes_id_seq OWNER TO orga;

--
-- Name: groupes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.groupes_id_seq OWNED BY public.groupes.id;


--
-- Name: hebdos; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.hebdos (
    id bigint NOT NULL,
    utilisateur_id bigint,
    numero_semaine integer,
    note character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    task_id bigint,
    year_id bigint,
    service_id bigint
);


ALTER TABLE public.hebdos OWNER TO orga;

--
-- Name: hebdos_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.hebdos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hebdos_id_seq OWNER TO orga;

--
-- Name: hebdos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.hebdos_id_seq OWNED BY public.hebdos.id;


--
-- Name: jours; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.jours (
    id bigint NOT NULL,
    utilisateur_id bigint,
    service_id bigint,
    numero_semaine character varying,
    date date,
    numero_jour integer,
    am_pm boolean,
    note character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.jours OWNER TO orga;

--
-- Name: jours_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.jours_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jours_id_seq OWNER TO orga;

--
-- Name: jours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.jours_id_seq OWNED BY public.jours.id;


--
-- Name: konfigurations; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.konfigurations (
    id bigint NOT NULL,
    key character varying,
    value character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.konfigurations OWNER TO orga;

--
-- Name: konfigurations_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.konfigurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.konfigurations_id_seq OWNER TO orga;

--
-- Name: konfigurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.konfigurations_id_seq OWNED BY public.konfigurations.id;


--
-- Name: lieus; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.lieus (
    id bigint NOT NULL,
    nom character varying,
    adresse text,
    phone character varying,
    note character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.lieus OWNER TO orga;

--
-- Name: lieus_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.lieus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lieus_id_seq OWNER TO orga;

--
-- Name: lieus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.lieus_id_seq OWNED BY public.lieus.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.logs (
    id bigint NOT NULL,
    date timestamp without time zone,
    adresse character varying,
    utilisateur_id integer,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.logs OWNER TO orga;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_id_seq OWNER TO orga;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    service_id bigint,
    note character varying,
    date date,
    date_fin date,
    utilisateur_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.messages OWNER TO orga;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO orga;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO orga;

--
-- Name: services; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.services (
    id bigint NOT NULL,
    lieu_id bigint,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.services OWNER TO orga;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_id_seq OWNER TO orga;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    groupe_id bigint,
    classe_id bigint,
    service_id bigint,
    nom character varying,
    code character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    repeat integer
);


ALTER TABLE public.tasks OWNER TO orga;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO orga;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: templates; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.templates (
    id bigint NOT NULL,
    am_pm1 boolean,
    work1_1 integer,
    work1_2 integer,
    work1_3 integer,
    work1_4 integer,
    work1_5 integer,
    am_pm2 boolean,
    work2_1 integer,
    work2_2 integer,
    work2_3 integer,
    work2_4 integer,
    work2_5 integer,
    am_pm3 boolean,
    work3_2 integer,
    work3_3 integer,
    work3_4 integer,
    work3_5 integer,
    am_pm4 boolean,
    work4_1 integer,
    work4_2 integer,
    work4_3 integer,
    work4_4 integer,
    work4_5 integer,
    am_pm5 boolean,
    work5_1 integer,
    work5_2 integer,
    work5_3 integer,
    work5_4 integer,
    work5_5 integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    nom character varying,
    description character varying,
    service_id integer,
    work3_1 integer
);


ALTER TABLE public.templates OWNER TO orga;

--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.templates_id_seq OWNER TO orga;

--
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.templates_id_seq OWNED BY public.templates.id;


--
-- Name: type_absences; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.type_absences (
    id bigint NOT NULL,
    code character varying,
    nom character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.type_absences OWNER TO orga;

--
-- Name: type_absences_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.type_absences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_absences_id_seq OWNER TO orga;

--
-- Name: type_absences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.type_absences_id_seq OWNED BY public.type_absences.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    admin boolean,
    last_connection timestamp without time zone
);


ALTER TABLE public.users OWNER TO orga;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO orga;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: utilisateurs; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.utilisateurs (
    id bigint NOT NULL,
    groupe_id bigint,
    service_id bigint,
    prenom character varying,
    nom character varying,
    email character varying,
    phone character varying,
    gsm character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id bigint,
    admin boolean,
    last_connection timestamp without time zone,
    inactive boolean
);


ALTER TABLE public.utilisateurs OWNER TO orga;

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.utilisateurs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.utilisateurs_id_seq OWNER TO orga;

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.utilisateurs_id_seq OWNED BY public.utilisateurs.id;


--
-- Name: wiki_pages; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.wiki_pages (
    id bigint NOT NULL,
    utilisateur_id integer,
    blog_category_id integer,
    service_id integer,
    groupe_id integer,
    keywords character varying,
    title character varying,
    problem_description text,
    solution_short text,
    solution_long text,
    blog_message_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.wiki_pages OWNER TO orga;

--
-- Name: wiki_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.wiki_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wiki_pages_id_seq OWNER TO orga;

--
-- Name: wiki_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.wiki_pages_id_seq OWNED BY public.wiki_pages.id;


--
-- Name: working_lists; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.working_lists (
    id bigint NOT NULL,
    work_id bigint,
    jour_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.working_lists OWNER TO orga;

--
-- Name: working_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.working_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.working_lists_id_seq OWNER TO orga;

--
-- Name: working_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.working_lists_id_seq OWNED BY public.working_lists.id;


--
-- Name: works; Type: TABLE; Schema: public; Owner: orga
--

CREATE TABLE public.works (
    id bigint NOT NULL,
    groupe_id bigint,
    classe_id bigint,
    service_id bigint,
    nom character varying,
    code character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    mark boolean,
    early_value integer,
    length integer,
    repeat integer
);


ALTER TABLE public.works OWNER TO orga;

--
-- Name: works_id_seq; Type: SEQUENCE; Schema: public; Owner: orga
--

CREATE SEQUENCE public.works_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.works_id_seq OWNER TO orga;

--
-- Name: works_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: orga
--

ALTER SEQUENCE public.works_id_seq OWNED BY public.works.id;


--
-- Name: absences id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.absences ALTER COLUMN id SET DEFAULT nextval('public.absences_id_seq'::regclass);


--
-- Name: ajouts id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.ajouts ALTER COLUMN id SET DEFAULT nextval('public.ajouts_id_seq'::regclass);


--
-- Name: blog_categories id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_categories ALTER COLUMN id SET DEFAULT nextval('public.blog_categories_id_seq'::regclass);


--
-- Name: blog_messages id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_messages ALTER COLUMN id SET DEFAULT nextval('public.blog_messages_id_seq'::regclass);


--
-- Name: blog_responses id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_responses ALTER COLUMN id SET DEFAULT nextval('public.blog_responses_id_seq'::regclass);


--
-- Name: bug_repports id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.bug_repports ALTER COLUMN id SET DEFAULT nextval('public.bug_repports_id_seq'::regclass);


--
-- Name: classes id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.classes ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: configurations id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.configurations ALTER COLUMN id SET DEFAULT nextval('public.configurations_id_seq'::regclass);


--
-- Name: demande_conges id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.demande_conges ALTER COLUMN id SET DEFAULT nextval('public.demande_conges_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: fermetures id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.fermetures ALTER COLUMN id SET DEFAULT nextval('public.fermetures_id_seq'::regclass);


--
-- Name: groupes id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.groupes ALTER COLUMN id SET DEFAULT nextval('public.groupes_id_seq'::regclass);


--
-- Name: hebdos id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.hebdos ALTER COLUMN id SET DEFAULT nextval('public.hebdos_id_seq'::regclass);


--
-- Name: jours id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.jours ALTER COLUMN id SET DEFAULT nextval('public.jours_id_seq'::regclass);


--
-- Name: konfigurations id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.konfigurations ALTER COLUMN id SET DEFAULT nextval('public.konfigurations_id_seq'::regclass);


--
-- Name: lieus id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.lieus ALTER COLUMN id SET DEFAULT nextval('public.lieus_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: templates id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.templates ALTER COLUMN id SET DEFAULT nextval('public.templates_id_seq'::regclass);


--
-- Name: type_absences id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.type_absences ALTER COLUMN id SET DEFAULT nextval('public.type_absences_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: utilisateurs id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.utilisateurs ALTER COLUMN id SET DEFAULT nextval('public.utilisateurs_id_seq'::regclass);


--
-- Name: wiki_pages id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.wiki_pages ALTER COLUMN id SET DEFAULT nextval('public.wiki_pages_id_seq'::regclass);


--
-- Name: working_lists id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.working_lists ALTER COLUMN id SET DEFAULT nextval('public.working_lists_id_seq'::regclass);


--
-- Name: works id; Type: DEFAULT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.works ALTER COLUMN id SET DEFAULT nextval('public.works_id_seq'::regclass);


--
-- Data for Name: absences; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.absences (id, type_absence_id, utilisateur_id, date, date_fin, remarque, created_at, updated_at, accord, halfday) FROM stdin;
\.
COPY public.absences (id, type_absence_id, utilisateur_id, date, date_fin, remarque, created_at, updated_at, accord, halfday) FROM '$$PATH$$/3308.dat';

--
-- Data for Name: ajouts; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.ajouts (id, utilisateur_id, date, am_pm, work1, work2, work3, work4, work5, created_at, updated_at) FROM stdin;
\.
COPY public.ajouts (id, utilisateur_id, date, am_pm, work1, work2, work3, work4, work5, created_at, updated_at) FROM '$$PATH$$/3310.dat';

--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3312.dat';

--
-- Data for Name: blog_categories; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.blog_categories (id, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.blog_categories (id, nom, description, created_at, updated_at) FROM '$$PATH$$/3313.dat';

--
-- Data for Name: blog_messages; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.blog_messages (id, utilisateur_id, blog_category_id, service_id, title, keywords, description, created_at, updated_at, date, groupe, classe, logbook, reviewed, reviewer) FROM stdin;
\.
COPY public.blog_messages (id, utilisateur_id, blog_category_id, service_id, title, keywords, description, created_at, updated_at, date, groupe, classe, logbook, reviewed, reviewer) FROM '$$PATH$$/3315.dat';

--
-- Data for Name: blog_responses; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.blog_responses (id, utilisateur_id, blog_message_id, description, created_at, updated_at) FROM stdin;
\.
COPY public.blog_responses (id, utilisateur_id, blog_message_id, description, created_at, updated_at) FROM '$$PATH$$/3317.dat';

--
-- Data for Name: bug_repports; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.bug_repports (id, utilisateur_id, date, nom, description, created_at, updated_at, status) FROM stdin;
\.
COPY public.bug_repports (id, utilisateur_id, date, nom, description, created_at, updated_at, status) FROM '$$PATH$$/3319.dat';

--
-- Data for Name: classes; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.classes (id, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.classes (id, nom, description, created_at, updated_at) FROM '$$PATH$$/3321.dat';

--
-- Data for Name: configurations; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.configurations (id, key, value, description, created_at, updated_at) FROM stdin;
\.
COPY public.configurations (id, key, value, description, created_at, updated_at) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: demande_conges; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.demande_conges (id, date, date_fin, date_demande, utilisateur_id, created_at, updated_at) FROM stdin;
\.
COPY public.demande_conges (id, date, date_fin, date_demande, utilisateur_id, created_at, updated_at) FROM '$$PATH$$/3325.dat';

--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.events (id, nom, date, note, service_id, created_at, updated_at) FROM stdin;
\.
COPY public.events (id, nom, date, note, service_id, created_at, updated_at) FROM '$$PATH$$/3327.dat';

--
-- Data for Name: fermetures; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.fermetures (id, nom, date, date_fin, note, service_id, created_at, updated_at) FROM stdin;
\.
COPY public.fermetures (id, nom, date, date_fin, note, service_id, created_at, updated_at) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: groupes; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.groupes (id, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.groupes (id, nom, description, created_at, updated_at) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: hebdos; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.hebdos (id, utilisateur_id, numero_semaine, note, created_at, updated_at, task_id, year_id, service_id) FROM stdin;
\.
COPY public.hebdos (id, utilisateur_id, numero_semaine, note, created_at, updated_at, task_id, year_id, service_id) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: jours; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.jours (id, utilisateur_id, service_id, numero_semaine, date, numero_jour, am_pm, note, created_at, updated_at) FROM stdin;
\.
COPY public.jours (id, utilisateur_id, service_id, numero_semaine, date, numero_jour, am_pm, note, created_at, updated_at) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: konfigurations; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.konfigurations (id, key, value, description, created_at, updated_at) FROM stdin;
\.
COPY public.konfigurations (id, key, value, description, created_at, updated_at) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: lieus; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.lieus (id, nom, adresse, phone, note, created_at, updated_at) FROM stdin;
\.
COPY public.lieus (id, nom, adresse, phone, note, created_at, updated_at) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.logs (id, date, adresse, utilisateur_id, description, created_at, updated_at) FROM stdin;
\.
COPY public.logs (id, date, adresse, utilisateur_id, description, created_at, updated_at) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.messages (id, service_id, note, date, date_fin, utilisateur_id, created_at, updated_at) FROM stdin;
\.
COPY public.messages (id, service_id, note, date, date_fin, utilisateur_id, created_at, updated_at) FROM '$$PATH$$/3341.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/3343.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.services (id, lieu_id, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.services (id, lieu_id, nom, description, created_at, updated_at) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.tasks (id, groupe_id, classe_id, service_id, nom, code, description, created_at, updated_at, repeat) FROM stdin;
\.
COPY public.tasks (id, groupe_id, classe_id, service_id, nom, code, description, created_at, updated_at, repeat) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.templates (id, am_pm1, work1_1, work1_2, work1_3, work1_4, work1_5, am_pm2, work2_1, work2_2, work2_3, work2_4, work2_5, am_pm3, work3_2, work3_3, work3_4, work3_5, am_pm4, work4_1, work4_2, work4_3, work4_4, work4_5, am_pm5, work5_1, work5_2, work5_3, work5_4, work5_5, created_at, updated_at, nom, description, service_id, work3_1) FROM stdin;
\.
COPY public.templates (id, am_pm1, work1_1, work1_2, work1_3, work1_4, work1_5, am_pm2, work2_1, work2_2, work2_3, work2_4, work2_5, am_pm3, work3_2, work3_3, work3_4, work3_5, am_pm4, work4_1, work4_2, work4_3, work4_4, work4_5, am_pm5, work5_1, work5_2, work5_3, work5_4, work5_5, created_at, updated_at, nom, description, service_id, work3_1) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: type_absences; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.type_absences (id, code, nom, description, created_at, updated_at) FROM stdin;
\.
COPY public.type_absences (id, code, nom, description, created_at, updated_at) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at, admin, last_connection) FROM stdin;
\.
COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at, admin, last_connection) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: utilisateurs; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.utilisateurs (id, groupe_id, service_id, prenom, nom, email, phone, gsm, created_at, updated_at, user_id, admin, last_connection, inactive) FROM stdin;
\.
COPY public.utilisateurs (id, groupe_id, service_id, prenom, nom, email, phone, gsm, created_at, updated_at, user_id, admin, last_connection, inactive) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: wiki_pages; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.wiki_pages (id, utilisateur_id, blog_category_id, service_id, groupe_id, keywords, title, problem_description, solution_short, solution_long, blog_message_id, created_at, updated_at) FROM stdin;
\.
COPY public.wiki_pages (id, utilisateur_id, blog_category_id, service_id, groupe_id, keywords, title, problem_description, solution_short, solution_long, blog_message_id, created_at, updated_at) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: working_lists; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.working_lists (id, work_id, jour_id, created_at, updated_at) FROM stdin;
\.
COPY public.working_lists (id, work_id, jour_id, created_at, updated_at) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: works; Type: TABLE DATA; Schema: public; Owner: orga
--

COPY public.works (id, groupe_id, classe_id, service_id, nom, code, description, created_at, updated_at, mark, early_value, length, repeat) FROM stdin;
\.
COPY public.works (id, groupe_id, classe_id, service_id, nom, code, description, created_at, updated_at, mark, early_value, length, repeat) FROM '$$PATH$$/3358.dat';

--
-- Name: absences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.absences_id_seq', 331, true);


--
-- Name: ajouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.ajouts_id_seq', 2391, true);


--
-- Name: blog_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.blog_categories_id_seq', 8, true);


--
-- Name: blog_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.blog_messages_id_seq', 39, true);


--
-- Name: blog_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.blog_responses_id_seq', 5, true);


--
-- Name: bug_repports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.bug_repports_id_seq', 6, true);


--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.classes_id_seq', 4, true);


--
-- Name: configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.configurations_id_seq', 1, false);


--
-- Name: demande_conges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.demande_conges_id_seq', 1, false);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.events_id_seq', 27, true);


--
-- Name: fermetures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.fermetures_id_seq', 27, true);


--
-- Name: groupes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.groupes_id_seq', 13, true);


--
-- Name: hebdos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.hebdos_id_seq', 18, true);


--
-- Name: jours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.jours_id_seq', 2024, true);


--
-- Name: konfigurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.konfigurations_id_seq', 11, true);


--
-- Name: lieus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.lieus_id_seq', 2, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.logs_id_seq', 62354, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.messages_id_seq', 8, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.services_id_seq', 3, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.tasks_id_seq', 4, true);


--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.templates_id_seq', 7, true);


--
-- Name: type_absences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.type_absences_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.users_id_seq', 35, true);


--
-- Name: utilisateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.utilisateurs_id_seq', 32, true);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.wiki_pages_id_seq', 4, true);


--
-- Name: working_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.working_lists_id_seq', 3402, true);


--
-- Name: works_id_seq; Type: SEQUENCE SET; Schema: public; Owner: orga
--

SELECT pg_catalog.setval('public.works_id_seq', 44, true);


--
-- Name: absences absences_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.absences
    ADD CONSTRAINT absences_pkey PRIMARY KEY (id);


--
-- Name: ajouts ajouts_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.ajouts
    ADD CONSTRAINT ajouts_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: blog_categories blog_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_categories
    ADD CONSTRAINT blog_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_messages blog_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_messages
    ADD CONSTRAINT blog_messages_pkey PRIMARY KEY (id);


--
-- Name: blog_responses blog_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_responses
    ADD CONSTRAINT blog_responses_pkey PRIMARY KEY (id);


--
-- Name: bug_repports bug_repports_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.bug_repports
    ADD CONSTRAINT bug_repports_pkey PRIMARY KEY (id);


--
-- Name: classes classes_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.classes
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: configurations configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.configurations
    ADD CONSTRAINT configurations_pkey PRIMARY KEY (id);


--
-- Name: demande_conges demande_conges_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.demande_conges
    ADD CONSTRAINT demande_conges_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: fermetures fermetures_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.fermetures
    ADD CONSTRAINT fermetures_pkey PRIMARY KEY (id);


--
-- Name: groupes groupes_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.groupes
    ADD CONSTRAINT groupes_pkey PRIMARY KEY (id);


--
-- Name: hebdos hebdos_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.hebdos
    ADD CONSTRAINT hebdos_pkey PRIMARY KEY (id);


--
-- Name: jours jours_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.jours
    ADD CONSTRAINT jours_pkey PRIMARY KEY (id);


--
-- Name: konfigurations konfigurations_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.konfigurations
    ADD CONSTRAINT konfigurations_pkey PRIMARY KEY (id);


--
-- Name: lieus lieus_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.lieus
    ADD CONSTRAINT lieus_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: type_absences type_absences_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.type_absences
    ADD CONSTRAINT type_absences_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: utilisateurs utilisateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT utilisateurs_pkey PRIMARY KEY (id);


--
-- Name: wiki_pages wiki_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT wiki_pages_pkey PRIMARY KEY (id);


--
-- Name: working_lists working_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.working_lists
    ADD CONSTRAINT working_lists_pkey PRIMARY KEY (id);


--
-- Name: works works_pkey; Type: CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_pkey PRIMARY KEY (id);


--
-- Name: index_absences_on_type_absence_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_absences_on_type_absence_id ON public.absences USING btree (type_absence_id);


--
-- Name: index_absences_on_utilisateur_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_absences_on_utilisateur_id ON public.absences USING btree (utilisateur_id);


--
-- Name: index_ajouts_on_utilisateur_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_ajouts_on_utilisateur_id ON public.ajouts USING btree (utilisateur_id);


--
-- Name: index_blog_messages_on_blog_category_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_blog_messages_on_blog_category_id ON public.blog_messages USING btree (blog_category_id);


--
-- Name: index_blog_messages_on_service_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_blog_messages_on_service_id ON public.blog_messages USING btree (service_id);


--
-- Name: index_blog_messages_on_utilisateur_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_blog_messages_on_utilisateur_id ON public.blog_messages USING btree (utilisateur_id);


--
-- Name: index_blog_responses_on_blog_message_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_blog_responses_on_blog_message_id ON public.blog_responses USING btree (blog_message_id);


--
-- Name: index_blog_responses_on_utilisateur_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_blog_responses_on_utilisateur_id ON public.blog_responses USING btree (utilisateur_id);


--
-- Name: index_bug_repports_on_utilisateur_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_bug_repports_on_utilisateur_id ON public.bug_repports USING btree (utilisateur_id);


--
-- Name: index_demande_conges_on_utilisateur_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_demande_conges_on_utilisateur_id ON public.demande_conges USING btree (utilisateur_id);


--
-- Name: index_events_on_service_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_events_on_service_id ON public.events USING btree (service_id);


--
-- Name: index_fermetures_on_service_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_fermetures_on_service_id ON public.fermetures USING btree (service_id);


--
-- Name: index_hebdos_on_service_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_hebdos_on_service_id ON public.hebdos USING btree (service_id);


--
-- Name: index_hebdos_on_task_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_hebdos_on_task_id ON public.hebdos USING btree (task_id);


--
-- Name: index_hebdos_on_utilisateur_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_hebdos_on_utilisateur_id ON public.hebdos USING btree (utilisateur_id);


--
-- Name: index_hebdos_on_year_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_hebdos_on_year_id ON public.hebdos USING btree (year_id);


--
-- Name: index_jours_on_service_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_jours_on_service_id ON public.jours USING btree (service_id);


--
-- Name: index_jours_on_utilisateur_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_jours_on_utilisateur_id ON public.jours USING btree (utilisateur_id);


--
-- Name: index_messages_on_service_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_messages_on_service_id ON public.messages USING btree (service_id);


--
-- Name: index_messages_on_utilisateur_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_messages_on_utilisateur_id ON public.messages USING btree (utilisateur_id);


--
-- Name: index_services_on_lieu_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_services_on_lieu_id ON public.services USING btree (lieu_id);


--
-- Name: index_tasks_on_classe_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_tasks_on_classe_id ON public.tasks USING btree (classe_id);


--
-- Name: index_tasks_on_groupe_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_tasks_on_groupe_id ON public.tasks USING btree (groupe_id);


--
-- Name: index_tasks_on_service_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_tasks_on_service_id ON public.tasks USING btree (service_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: orga
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: orga
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: index_utilisateurs_on_groupe_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_utilisateurs_on_groupe_id ON public.utilisateurs USING btree (groupe_id);


--
-- Name: index_utilisateurs_on_service_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_utilisateurs_on_service_id ON public.utilisateurs USING btree (service_id);


--
-- Name: index_utilisateurs_on_user_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_utilisateurs_on_user_id ON public.utilisateurs USING btree (user_id);


--
-- Name: index_working_lists_on_jour_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_working_lists_on_jour_id ON public.working_lists USING btree (jour_id);


--
-- Name: index_working_lists_on_work_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_working_lists_on_work_id ON public.working_lists USING btree (work_id);


--
-- Name: index_works_on_classe_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_works_on_classe_id ON public.works USING btree (classe_id);


--
-- Name: index_works_on_groupe_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_works_on_groupe_id ON public.works USING btree (groupe_id);


--
-- Name: index_works_on_service_id; Type: INDEX; Schema: public; Owner: orga
--

CREATE INDEX index_works_on_service_id ON public.works USING btree (service_id);


--
-- Name: absences fk_rails_01905dceab; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.absences
    ADD CONSTRAINT fk_rails_01905dceab FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: working_lists fk_rails_024b0deb6b; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.working_lists
    ADD CONSTRAINT fk_rails_024b0deb6b FOREIGN KEY (work_id) REFERENCES public.works(id);


--
-- Name: ajouts fk_rails_27ad140c06; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.ajouts
    ADD CONSTRAINT fk_rails_27ad140c06 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: services fk_rails_29ee5530cc; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT fk_rails_29ee5530cc FOREIGN KEY (lieu_id) REFERENCES public.lieus(id);


--
-- Name: hebdos fk_rails_2beb9d1bf1; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.hebdos
    ADD CONSTRAINT fk_rails_2beb9d1bf1 FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: utilisateurs fk_rails_2d7f78bc98; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT fk_rails_2d7f78bc98 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: utilisateurs fk_rails_2e57212d6a; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT fk_rails_2e57212d6a FOREIGN KEY (groupe_id) REFERENCES public.groupes(id);


--
-- Name: bug_repports fk_rails_2e875501e3; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.bug_repports
    ADD CONSTRAINT fk_rails_2e875501e3 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: hebdos fk_rails_3bfd6d9ba1; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.hebdos
    ADD CONSTRAINT fk_rails_3bfd6d9ba1 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: tasks fk_rails_4666c71c63; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_rails_4666c71c63 FOREIGN KEY (classe_id) REFERENCES public.classes(id);


--
-- Name: tasks fk_rails_471c7d6b72; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_rails_471c7d6b72 FOREIGN KEY (groupe_id) REFERENCES public.groupes(id);


--
-- Name: working_lists fk_rails_47a9f48ec7; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.working_lists
    ADD CONSTRAINT fk_rails_47a9f48ec7 FOREIGN KEY (jour_id) REFERENCES public.jours(id);


--
-- Name: blog_responses fk_rails_567257db3c; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_responses
    ADD CONSTRAINT fk_rails_567257db3c FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: works fk_rails_6193f61ffa; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_rails_6193f61ffa FOREIGN KEY (groupe_id) REFERENCES public.groupes(id);


--
-- Name: jours fk_rails_661d514733; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.jours
    ADD CONSTRAINT fk_rails_661d514733 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: demande_conges fk_rails_729cf6104d; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.demande_conges
    ADD CONSTRAINT fk_rails_729cf6104d FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: blog_messages fk_rails_79cb1f4ea9; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_messages
    ADD CONSTRAINT fk_rails_79cb1f4ea9 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: utilisateurs fk_rails_9189f91c53; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT fk_rails_9189f91c53 FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: blog_responses fk_rails_a290f1a5b1; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_responses
    ADD CONSTRAINT fk_rails_a290f1a5b1 FOREIGN KEY (blog_message_id) REFERENCES public.blog_messages(id);


--
-- Name: fermetures fk_rails_a2c55913ce; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.fermetures
    ADD CONSTRAINT fk_rails_a2c55913ce FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: messages fk_rails_a43ca7dd41; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_a43ca7dd41 FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: works fk_rails_a5b6ca6089; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_rails_a5b6ca6089 FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: blog_messages fk_rails_c123c2783a; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_messages
    ADD CONSTRAINT fk_rails_c123c2783a FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: blog_messages fk_rails_c49356f00a; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.blog_messages
    ADD CONSTRAINT fk_rails_c49356f00a FOREIGN KEY (blog_category_id) REFERENCES public.blog_categories(id);


--
-- Name: jours fk_rails_d9f2bb24dc; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.jours
    ADD CONSTRAINT fk_rails_d9f2bb24dc FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: messages fk_rails_db7ace0f80; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_rails_db7ace0f80 FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: tasks fk_rails_de7026eb4d; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_rails_de7026eb4d FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: absences fk_rails_f4043bdcfe; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.absences
    ADD CONSTRAINT fk_rails_f4043bdcfe FOREIGN KEY (type_absence_id) REFERENCES public.type_absences(id);


--
-- Name: works fk_rails_f466c606bb; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_rails_f466c606bb FOREIGN KEY (classe_id) REFERENCES public.classes(id);


--
-- Name: events fk_rails_ff93bdc68d; Type: FK CONSTRAINT; Schema: public; Owner: orga
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT fk_rails_ff93bdc68d FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- PostgreSQL database dump complete
--

